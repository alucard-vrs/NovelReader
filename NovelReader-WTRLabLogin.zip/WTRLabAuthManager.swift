import Foundation
import WebKit
import SwiftUI

@MainActor
final class WTRLabAuthManager: ObservableObject {
    @Published private(set) var cookie = ""
    @Published private(set) var isAuthenticated = false

    func update(from cookieStore: WKHTTPCookieStore) async {
        let cookies = await allCookies(from: cookieStore)
        let wtrCookies = cookies.filter { cookie in
            let domain = cookie.domain.lowercased()
            return domain == "wtr-lab.com" || domain.hasSuffix(".wtr-lab.com")
        }

        guard !wtrCookies.isEmpty else {
            cookie = ""
            isAuthenticated = false
            return
        }

        cookie = wtrCookies
            .sorted { $0.name < $1.name }
            .map { "\($0.name)=\($0.value)" }
            .joined(separator: "; ")

        isAuthenticated = true
    }

    func setCookieHeader(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        cookie = trimmed
        isAuthenticated = !trimmed.isEmpty
    }

    func clear() {
        cookie = ""
        isAuthenticated = false
    }

    private func allCookies(from store: WKHTTPCookieStore) async -> [HTTPCookie] {
        await withCheckedContinuation { continuation in
            store.getAllCookies { cookies in
                continuation.resume(returning: cookies)
            }
        }
    }
}

struct WTRLabLoginView: View {
    @ObservedObject var authManager: WTRLabAuthManager
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            WTRLabLoginWebView(authManager: authManager)
                .navigationTitle("WTR-LAB Login")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button("Cancel") {
                            dismiss()
                        }
                    }
                }
        }
    }
}

private struct WTRLabLoginWebView: UIViewRepresentable {
    @ObservedObject var authManager: WTRLabAuthManager

    func makeCoordinator() -> Coordinator {
        Coordinator(authManager: authManager)
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true

        let request = URLRequest(
            url: URL(string: "https://wtr-lab.com/en/auth/login")!
        )
        webView.load(request)

        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate {
        private let authManager: WTRLabAuthManager

        init(authManager: WTRLabAuthManager) {
            self.authManager = authManager
        }

        func webView(
            _ webView: WKWebView,
            didFinish navigation: WKNavigation!
        ) {
            Task { @MainActor in
                let store = webView.configuration.websiteDataStore.httpCookieStore
                await authManager.update(from: store)
            }
        }
    }
}
